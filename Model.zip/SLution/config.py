import os
import numpy as np

DATA_PATH = os.path.join('MP_Data')
actions = np.array(['hello','cat','iloveyou'])
no_sequences = 30
sequence_length = 30
start_folder = 30
