import os
import cv2
import numpy as np
import mediapipe as mp

from helpers import mediapipe_detection, draw_styled_landmarks, extract_keypoints
from config import DATA_PATH, actions, no_sequences, sequence_length


def data_collection():
    # יצירת מבנה התיקיות אם הוא לא קיים
    if not os.path.exists(DATA_PATH):
        os.makedirs(DATA_PATH)
        for action in actions:
            for sequence in range(no_sequences):
                os.makedirs(os.path.join(DATA_PATH, action, str(sequence)))
    else:
        # בדיקה אם התיקיות עבור actions חסרות
        for action in actions:
            action_path = os.path.join(DATA_PATH, action)
            if not os.path.exists(action_path):
                print(f"Missing directory for action '{action}', creating directories...")
                for sequence in range(no_sequences):
                    os.makedirs(os.path.join(action_path, str(sequence)))

    # הפעלת המצלמה
    cap = cv2.VideoCapture(0)

    # הגדרת מודל Mediapipe
    with mp.solutions.holistic.Holistic(min_detection_confidence=0.5, min_tracking_confidence=0.5) as holistic:
        for action in actions:
            print(f"Collecting data for action: {action}")
            for sequence in range(no_sequences):
                print(f" Collecting sequence {sequence} for action {action}")
                for frame_num in range(sequence_length):
                    # קריאת פריים מהמצלמה
                    ret, frame = cap.read()

                    if not ret:
                        print("Unable to read frame from camera. Exiting...")
                        break

                    # זיהוי Mediapipe
                    image, results = mediapipe_detection(frame, holistic)

                    # ציור הנקודות על המסך
                    draw_styled_landmarks(image, results)

                    # הצגת הודעה על המסך בתחילת רצף
                    if frame_num == 0:
                        cv2.putText(image, f'STARTING COLLECTION for {action}', (50, 200),
                                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2, cv2.LINE_AA)
                        cv2.putText(image, f'Sequence: {sequence}', (50, 250),
                                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2, cv2.LINE_AA)
                        cv2.imshow('OpenCV Feed', image)
                        cv2.waitKey(500)

                    # שמירת נקודות המפתח
                    keypoints = extract_keypoints(results)
                    npy_path = os.path.join(DATA_PATH, action, str(sequence), f"{frame_num}.npy")
                    np.save(npy_path, keypoints)

                    # הצגת הפריים על המסך
                    cv2.imshow('OpenCV Feed', image)

                    # עצירה בלחיצה על 'q'
                    if cv2.waitKey(10) & 0xFF == ord('q'):
                        print("Exiting data collection...")
                        cap.release()
                        cv2.destroyAllWindows()
                        return


    # שחרור המצלמה וסגירת חלונות
    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    data_collection()
