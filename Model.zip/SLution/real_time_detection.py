import cv2
import numpy as np
import os

# השתקת הודעות לוגים של TensorFlow
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
from tensorflow.keras.models import load_model
from helpers import mediapipe_detection, draw_styled_landmarks, extract_keypoints
from config import actions, sequence_length
import mediapipe as mp
import contextlib
import sys


# פונקציה להשתקת stdout
@contextlib.contextmanager
def suppress_stdout():
    with open(os.devnull, 'w') as devnull:
        old_stdout = sys.stdout
        sys.stdout = devnull
        try:
            yield
        finally:
            sys.stdout = old_stdout


def real_time_detection():
    model = load_model('model.h5')
    sequence = []
    sentence = []
    threshold = 0.9

    cap = cv2.VideoCapture(0)
    with mp.solutions.holistic.Holistic(min_detection_confidence=0.5, min_tracking_confidence=0.5) as holistic:
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                print("Failed to read frame from camera. Exiting...")
                break

            # Mediapipe detection
            image, results = mediapipe_detection(frame, holistic)
            draw_styled_landmarks(image, results)
            keypoints = extract_keypoints(results)
            sequence.append(keypoints)
            sequence = sequence[-sequence_length:]

            # Prediction logic
            if len(sequence) == sequence_length:
                # השתקת ההדפסות במהלך החיזוי
                with suppress_stdout():
                    res = model.predict(np.expand_dims(sequence, axis=0))[0]

                # Debug: Print prediction details
                print(f"Predicted probabilities: {res}")
                print(f"Highest probability: {res[np.argmax(res)]}")
                print(f"Predicted action index: {np.argmax(res)}")
                print(f"Predicted action: {actions[np.argmax(res)]}")
                if res[np.argmax(res)] > threshold:

                    if len(sentence) == 0 or actions[np.argmax(res)] != sentence[-1]:
                        sentence.append(actions[np.argmax(res)])
                if len(sentence) > 5:
                    sentence = sentence[-5:]

            # Draw the canvas
            cv2.rectangle(image, (0, 0), (640, 40), (245, 117, 16), -1)
            cv2.putText(image, ' '.join(sentence), (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2, cv2.LINE_AA)

            # Display the frame
            cv2.imshow('Realtime Detection', image)

            # Exit gracefully on 'q'
            if cv2.waitKey(10) & 0xFF == ord('q'):
                break

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    real_time_detection()
