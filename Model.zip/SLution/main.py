import data_collection
import model_training
import real_time_detection

if __name__ == "__main__":
    while True:
        print("\nMenu:")
        print("1. Data Collection")
        print("2. Training")
        print("3. Real-Time Detection")
        print("0. Exit")

        choice = input("Choose an option: ")

        if choice == '1':
            print("Starting Data Collection...")
            data_collection.data_collection()
        elif choice == '2':
            print("Starting Model Training...")
            model_training.train_model()
        elif choice == '3':
            print("Starting Real-Time Detection...")
            real_time_detection.real_time_detection()
        elif choice == '0':
            print("Exiting...")
            break
        else:
            print("Invalid choice. Please choose a valid option.")
